//1
setInterval(function tiempo() {
    var dies = ["Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres", "Dissabte", "Diumenge"];
    var mesos = ["Gener", "Febrer", "Març", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"];
    
    var ara = new Date(); //Generem un objecte de tips data (per això el "new")
    var hora = ara.getHours(); //Obtenim les variables segons els metodes que ja estàn implementats per defecte.
    var minuts = ara.getMinutes();
    var segons = ara.getSeconds();
    var diaSetmana = dies[ara.getDay()]; // getDay() retorna de 0 (Diumenge) a 6 (Dissabte)
    var mesActual = mesos[ara.getMonth() + 1]; // getMonth() retorna de 0 a 11
    document.getElementById("hora").textContent="Ara és " + diaSetmana + ", " + hora + ":" + minuts + ":" + segons + " de " + mesActual; //Actualitzes el textcontext segons les teues variables, sempre el element amb id "hora" si existeix
}, 1000); // Actualitzar cada 1 segon

//2
//Mostra un alert en cada pàgina, no li pose ninguna funció perque vull que es faça sempre
alert("Esto es un mensaje para cada página. "+ document.body.style.backgroundColor +" es el color de fondo.");


//3
//Mostrem un tooltip per damunt dels links quan passem sobre ells
  
var links = document.getElementsByClassName("link");
var p = document.getElementById("AMostrar"); //el id del element que tenim que mostrar

for (var i = 0; i < links.length; i++) { //Per cada link, és una HTMLCollection
    links[i].addEventListener("mouseover", function(event) {
        p.style.display = "block";
        p.style.border="1px solid black";
        p.style.color="black";
        p.style.backgroundColor="white";
        p.style.padding="3px";

        // Actualitzem la posición del tooltip per baix del ratolí
        p.style.position = "absolute";
        p.style.left = event.pageX + 'px';
        p.style.top = event.pageY + 10 + 'px'; // 10px per baix del ratolí
    });

    links[i].addEventListener("mousemove", function(event) {
        // Mentre el ratón es moga, actualitzem la posició
        p.style.left = event.pageX + 'px';
        p.style.top = event.pageY + 10 + 'px';
    });

    links[i].addEventListener("mouseout", function() {
        p.style.display = "none";
    });
}
//4
//Esto és el menú desplegable
var desplegable = document.getElementById('desplegable'); //Capturem el element amb id "desplegable"
var link = document.getElementById("secreta"); //Capturem el element amb id "secreta"
link.style.display="none";

desplegable.addEventListener('click', function() { //Si fem click en el element
  
  if (this.style.left === '0px') {
    this.style.left = "-70px";
    link.style.display="none";
  } else {
    this.style.left = '0px';
    link.style.display="block";
  }
});


link.addEventListener('click',function() {//Si fem click en el element
  window.location.href='./js/Aplicacions_javascript/pagina.html'; //Redirigeix a la nova pàgina que havem creat respecte les anteriors
});
//5
//Aquest és el banner
window.onload=function cabraXillant() {
    var banner= document.getElementById('banner');
    if (banner.style.display="none") {
        banner.style.display="block";
        banner.src="imagenes/cabraxillant.jpg";
        banner.style="height: 100px;"
    }
}
//6
//Al iniciar la pàgina comença la nostra funció de canviar el color de fons
window.onload = function teclesCanviarFons() {
    document.addEventListener("keydown", function canviarColor(e) { //Dispara la funció cada vegada que apretem una tecla
        if (e.key === "c" && e.ctrlKey) { //Si mantenim apretades les tecles indicades
            document.body.style.backgroundImage="none"; //Lleva la imatge de fons
            var color = "rgb(";
            for (let i = 0; i < 3; i++) { //Fa un bucle tres vegades on anyadeix "x, x, x" aquestes x siguent un numero i les comes
                color += Math.floor(Math.random() * 256); //És aleatori i dins del rang
                if (i < 2) {
                    color += ",";
                }
            }
            color += ")";//Acaba posant-li un parentesi final a rgb(x,x,x)
            document.body.style.backgroundColor = color; //Li assigna el color random fet nostre anterior al fons
          }
    });
};
//8
//Anyadim un mapa Leafleet (en Google hi havia que introduïr la targeta)
var map = L.map('map').setView([39.0008061, -0.5409501], 13); //Creem el mapa (de ningún lloc), però ja té el requadre, la posició i el s controls
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { //Carrega la imatge de les coordenades del mapa (veiem què és un png), utilitza \ que es gastat per als caracters de escape
    maxZoom: 19,
    attribution: '<a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>' //Mostra el copyright
}).addTo(map);
var marker = L.marker([39.0008061, -0.5409501]).addTo(map); //Anyadim el marcador al mapa
var marker2 = L.marker([39.0008061, -0.52]).addTo(map); //Anyadim el marcador al mapa
marker.bindPopup("<b>Hello world!</b><br>Sóc el popup que has clicat.").openPopup(); //Mitjançant bindpopup podem triar el text que posa quan fem click
marker2.bindPopup("Pots crear tants marcadors com vulgues").openPopup();

var popup = L.popup();

function onMapClick(e) {
    popup
        .setLatLng(e.latlng)
        .setContent("En la posició " + e.latlng.toString()+" no hi han cabres.") //Mostra la longitud i latitud
        .openOn(map);
}

map.on('click', onMapClick); //Quan fem click es dispara la funció
//9
//Obtenim els elements del DOM que anem a utilitzar per a fer els dos selects
var animal = document.getElementById('animal');
var rassa = document.getElementById('rassa');
var imatge = document.getElementById('imatge');

// Les races que té cada tipus d'animal
var races = {
  cabres: {
    "merina": "./imagenes/images.jpg",
    "churra": "./imagenes/images.jpeg"
  },
  cabres2: {
    "alpina": "./imagenes/80772729-lindo-diario-cabra-gritando-día-soleado.jpg",
    "nose": "./imagenes/cabraxillant.jpg"
  }
};


animal.addEventListener('change', function () {// Quan canviem el tipus d'animal

  var seleccionat = animal.value; //Obtenim el valor del animal sesleccionat
  rassa.innerHTML = '';        // Buidem el selector de races
  imatge.src = '';             // Eliminem la imatge actual
  imatge.style.display = "none"; // Ocultem la imatge

  if (races[seleccionat]) {
    rassa.disabled = false; //Activem la opció per a seleccionar la raça (si està disabled entonces disabled=true)

    // Afegim opció per defecte
    rassa.innerHTML = `<option value="">-- Selecciona raça --</option>`;

    // Afegim les opcions disponibles per al tipus seleccionat
    Object.keys(races[seleccionat]).forEach(function (r) { //El foreach no funciona amb htmlCollections així que el transformem en un array, podriem fer-ho amb un for normal però tindria menys gràcia
      var op = document.createElement('option'); //Creem un element option
      op.value = r; //Li assignem el valor de r
      op.textContent = r.charAt(0).toUpperCase() + r.slice(1); // Capitalitzem sols la primera lletra per a fer-ho bonico
      rassa.appendChild(op); //Ho anyadim per aque mostre les opcions
    });
  } else { //Si raça no té una key on podem traure el seu valor
    rassa.disabled = true; //Ho desactivem
  }
});

// Quan canviem la raça
rassa.addEventListener('change', function () {
  var tipus = animal.value;//li havem assignat que puga ser de 
  var raza = rassa.value; //Pot ser de dos tipus

  if (tipus && raza) { //Si les dos coses estàn seleccionades
    imatge.src = races[tipus][raza]; // Assignem la imatge corresponent
    imatge.style.display = "block";  // Mostrem la imatge
  } else {
    imatge.style.display = "none";
  }
});
//10
//Fem un try-catch
var input = document.getElementById('numero');
var boton = document.getElementById('calcular'); //Ja tenim un id amb nom boton
var resultado = document.getElementById('resultado');

boton.addEventListener('click', function () {
try {
var valor = input.value;

    if (valor.trim() === "") {
    throw new Error("El campo está vacío.");
    }

var numero = parseFloat(valor); //Agafem el valor float del input.value

    if (isNaN(numero)) { //Si el valor float és NaN llança el error i com està dins de un trycatch el agafa aquest.
    throw new Error("Eso no es un número válido.");
    }

    resultado.textContent = "El doble es: " + (numero * 2);
} catch (error) {
    resultado.textContent = "Error: " + error.message;
}finally{
    resultado.textContent+="!";
}
});