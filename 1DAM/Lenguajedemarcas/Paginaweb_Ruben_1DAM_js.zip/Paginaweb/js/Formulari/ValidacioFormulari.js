//Agafem els inputs
var email = document.getElementById('email');
var date = document.getElementById('date');
var text = document.getElementById('text');
var boton = document.getElementById('boton');

function comprovar() {
var emailCorrecte = email.value.includes('@'); //Si el camp de mail conté un @ indica que és un mail, o sino dona false
var dataCorrecta = /^\d{2}\/\d{2}\/\d{4}$/.test(date.value); //Verifica que la data tinga aquesta EXPRESSIO REGULAR
var textLlongitudCorrecte = text.value.length >= 5; //Verifica que el camp té una longitud igual o major que 5
var textObligatori = text.value.trim() !== ''; // Comprovem que el camp no està buit (encara què és un pooc sensesentit si tenim el de dalt, però era un punt)

    // Soles mostrar el botó si les condicions són correctes
    if (emailCorrecte && dataCorrecta && textLlongitudCorrecte && textObligatori) { //Si acomplim totes les caracteristiques el valor display es posa en block, i si no les acomplim es posa en none
        boton.style.display = 'block';
    } else {
        boton.style.display = 'none';
    }
}

//Crida a la funció comprovar que verifica els inputs del formulari
email.addEventListener('input', comprovar);
date.addEventListener('input', comprovar);
text.addEventListener('input', comprovar);

//Conta els caracters del textarea (punt 16)
var textarea = document.getElementById('textarea');
var lloc = document.getElementById('numerocaracters');
var reset = document.getElementById('reset');

function contar() {
  lloc.textContent = textarea.value.length;
}

function resetear() {
  textarea.value='';
  lloc.textContent = '0';
}

textarea.addEventListener('input', contar);
reset.addEventListener('click', resetear);

//Esto crea un nou element cada vegada que active el checkbox
  var checkbox = document.getElementById('checkbox');
  var contenedor = document.getElementById('contenedorItems');

  function mostrar(event) { //p sols existeix en l'altra funció així que li passem el event (que fa rferència al objecte)
  event.target.textContent = "Has fet click en el element"; //event.target fa és el objecte del event
}

  function anyadir() {

    if (checkbox.checked) {
      var p = document.createElement('p');
      p.textContent = "Fes click aci";
      contenedor.appendChild(p);
      p.addEventListener("click", mostrar)
    }
  }

  checkbox.addEventListener("change", anyadir);