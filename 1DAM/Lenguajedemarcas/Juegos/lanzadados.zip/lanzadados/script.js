let estadisticas=[0,0,0,0,0,0];
var imagenesDado=[
    "imgs/1.png",
    "imgs/2.png",
    "imgs/3.png",
    "imgs/4.png",
    "imgs/5.png",
    "imgs/6.png"
];
var dado=document.getElementById("dado");
var btnlanzar=document.getElementById("buttonLanzar");
var btnEstadisticas=document.getElementById("botonEstadisticas");
var reiniciar= document.getElementById("botonreiniciarEstadisticas");
var contenedor=document.getElementById("estadisticas");

if (contenedor.innerHTML!="") {
    reiniciar.style.display="none";
}

function numeroAleatorio() {
    return Math.floor(Math.random()*6)+1;
}
function lanzarDado() {
    dado.src="imgs/roll.gif";
    btnlanzar.style.display="none"; //Desactiva el boton lanzar

    setTimeout (function() {
        var resultado = numeroAleatorio();
        dado.src=imagenesDado[resultado-1];
        estadisticas[resultado-1]++;

        btnlanzar.style.display="block";
    }, 2000);
}
function mostrarEstadisticas() {
    contenedor.innerHTML = "<h2>Estadísticas</h2><ul></ul>";
    var lista = contenedor.querySelector("ul");

    for (let index = 0; index < estadisticas.length; index++) {
        var estadisticaElemento = document.createElement('li');
        estadisticaElemento.id = `estadistica${index}`;
        estadisticaElemento.textContent = `Cara ${index + 1}: ${estadisticas[index]} veces`;
        lista.appendChild(estadisticaElemento);
    }

    btnEstadisticas.style.display = "none";
    reiniciar.style.display = "block";
}
function reiniciarEstadisticas() {
    for (let i = 0; i < estadisticas.length; i++) {
        estadisticas[i] = 0;
    }
    contenedor.innerHTML = "<h2>Estadísticas</h2><ul></ul>";
    btnEstadisticas.style.display = "block";
    reiniciar.style.display = "none";
}
function iniciar() {
    btnlanzar.addEventListener("click", lanzarDado);
    btnEstadisticas.addEventListener("click", mostrarEstadisticas);
    reiniciar.addEventListener("click", reiniciarEstadisticas);
}
window.onload=function(){
    iniciar();
}